console.log("server.js");

var express = require("express");
var cors = require('cors');
var app = express();
//app.use(cors());
app.use(cors({
	credentials: true,
	origin: "*"
  }));


var bodyParser = require("body-parser");
app.use(bodyParser.urlencoded());
app.use(bodyParser.json());

var http = require("http").createServer(app);
//var io = require("socket.io")(http);
const io = require('socket.io')(http, {
	cors: {
	  origin: '*',
	  credentials:true,
	}
  });

var mysql = require("mysql");
var connection = mysql.createConnection({
	"host": "localhost",
	"user": "root",
	"password": "",
	"database": "chat_app"
});

connection.connect(function (error) {
	app.get("/", function (request, result) {
		result.end("Hello world !");
	});

	app.use(function (req, res, next) {
	    res.setHeader('Access-Control-Allow-Origin', '*');
		
	    next();
	});
	app.get("/get_users", function (request, result) {
		
		connection.query("SELECT * FROM users", function (error, users) {
			result.end(JSON.stringify(users));
		});
	});
	app.get("/get_groups", function (request, result) {
		
		connection.query("SELECT * FROM group_details", function (error, group) {
			result.end(JSON.stringify(group));
		});
	});
	app.post("/get_messages", function (request, result) {
	
		connection.query("SELECT * FROM messages WHERE (sender = '" + request.body.sender + "' AND receiver = '" + request.body.receiver + "') OR (sender = '" + request.body.receiver + "' AND receiver = '" + request.body.sender + "')", function (error, messages) {
			result.end(JSON.stringify(messages));
		});
	});
	app.post("/get_group_messages", function (request, result) {
		console.log(request.body)
		connection.query("SELECT * FROM messages WHERE receiver = '"+request.body.receiver+"'", function (error, messages) {
			result.end(JSON.stringify(messages));
		});
	});
	var users = [];

	 io.on("connection", function (socket) {
	 	 //console.log("socket connected = " + socket.id);
		  console.log("User connected: ",  socket.id);
		  socket.on("user_connected", function (username) {
			  users[username] = socket.id;
			  io.emit("user_connected", username);
			  /* io.emit("join_room", {'username': username,'roomname' : 'MyGroup'});
			  socket.join('MyGroup'); */
		  });
		  socket.on("join_room", function (data) {
			  //console.log(data.roomname)
			/* users[username] = socket.id;
			io.emit("user_connected", username); */
			io.emit("join_room", {'username': data.username,'roomname' : data.roomname});
			socket.join(data.roomname);
		});

	 	socket.on("new_user", function (username) {
	 		connection.query("SELECT * FROM users WHERE username = '" + username + "'", function (error, result) {
	 			if (result.length == 0) {
	 				connection.query("INSERT INTO users(username) VALUES('" + username + "')", function (error, result) {
	 					io.emit("new_user", username);
	 				});
	 			} else {
	 				io.emit("new_user", username);
	 			}
	 		});
	 	});

		 socket.on("send_message", function (data) {
			 console.log(data.receiver);
			 if(data.msg_type == 'group')
			 {
			//	 console.log(data);
				 
				//socket.on('send_message', function (msg) {
					io.to(data.receiver).emit('message_received', data);
					connection.query("INSERT INTO messages (sender, receiver, message) VALUES ('" + data.sender + "', '" + 'MyGroup' + "', '" + data.message + "')", function (error, result) {
					});
//				});
				//console.log("ddddd");
			 }
			 else
			 {
				var socketId = users[data.receiver];
				console.log(socketId);
				console.log(data);
				socket.to(socketId).emit("message_received", data);
				connection.query("INSERT INTO messages (sender, receiver, message) VALUES ('" + data.sender + "', '" + data.receiver + "', '" + data.message + "')", function (error, result) {
					
				});
			 }
			
			
		});

		socket.on("delete_message", function (id) {
			connection.query("DELETE FROM messages WHERE id = '" + id + "'", function (error, result) {
				io.emit("delete_message", id);
			});
		})

		socket.on("new_message", function (data) {
			console.log("ddd");

			console.log("INSERT INTO messages(sender, message) VALUES('" + data.username + "', '" + data.message + "')");
			
			connection.query("INSERT INTO messages(sender, message) VALUES('" + data.username + "', '" + data.message + "')", function (error, result) {
				console.log(result);

				//data.id = result.insertId;
				io.emit("new_message", data);
			});
		});

		socket.on('base64 file', function (msg) {
			console.log('received base64 file from' + msg.username);
			socket.username = msg.username;
			console.log(msg.file);
			
			// socket.broadcast.emit('base64 image', //exclude sender
			io.sockets.emit('base64 file',  //include sender
		
				{
				  username: socket.username,
				  file: msg.file,
				  fileName: msg.fileName
				}
		
			);
		});
	});
});

http.listen(3000, function () {
	console.log("Listening :3000");
});